# app/app.py
import streamlit as st
import pickle
import pandas as pd
import os

# -----------------------------
# Custom CSS for dark blue background
# -----------------------------
st.markdown(
    """
    <style>
    .stApp {
        background-color: #0a1f44;  /* Dark blue */
        color: white;
    }
    textarea, .stButton>button {
        background-color: #1a335d; /* slightly lighter blue for inputs/buttons */
        color: white;
    }
    .stTextInput>div>input {
        background-color: #1a335d !important;
        color: white !important;
    }
    .stMarkdown {
        color: white;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# -----------------------------
# Load model and vectorizer
# -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "../model/sentiment_model.pkl")
VECT_PATH = os.path.join(BASE_DIR, "../model/tfidf_vectorizer.pkl")

with open(MODEL_PATH, "rb") as f:
    loaded_model = pickle.load(f)

with open(VECT_PATH, "rb") as f:
    loaded_vectorizer = pickle.load(f)

# -----------------------------
# Streamlit App
# -----------------------------
st.set_page_config(page_title="Flipkart Sentiment Analyzer", page_icon="🛒", layout="wide")

st.title("Flipkart Customer Review Sentiment Analysis 🛒")
st.write("Enter a customer review below and get the predicted sentiment (Positive/Negative) instantly!")

# Text input
review = st.text_area("Enter Review Text:", height=150)

if st.button("Analyze Sentiment"):
    if review.strip() == "":
        st.warning("Please enter a review to analyze.")
    else:
        # Convert text to vector
        review_vec = loaded_vectorizer.transform([review])
        # Predict sentiment
        prediction = loaded_model.predict(review_vec)[0]

        # Display result
        if prediction == 1:
            st.success("Positive Review ✅")
        else:
            st.error("Negative Review ❌")

# Optional: Display some example reviews
st.markdown("---")
st.subheader("Example Reviews")
example_reviews = [
    "The product quality is amazing, I loved it!",
    "Very bad service, delivery was delayed.",
    "Good value for money, works perfectly.",
    "Shuttle broke after first use, disappointed."
]

for r in example_reviews:
    st.write(f"- {r}")
