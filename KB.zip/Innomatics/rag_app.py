import boto3

# =========================
# 🔧 CONFIGURATION
# =========================
REGION = "us-east-1"
KNOWLEDGE_BASE_ID = "W05C7DXU51"
MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"

# 🔑 ADD YOUR IAM USER CREDENTIALS HERE
AWS_ACCESS_KEY = "AKIA47CRXDNN3XK6FO3Q"
AWS_SECRET_KEY = "2eyuLuP1hhK1ixxbeVHljgQqvY5zhJ5UYBRmjk6M"

# =========================
# 🚀 CREATE CLIENT
# =========================
client = boto3.client(
    "bedrock-agent-runtime",
    region_name="us-east-1",
    aws_access_key_id="AKIA47CRXDNN3XK6FO3Q",
    aws_secret_access_key="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",
)

# =========================
# 🔍 QUERY FUNCTION (RAG)
# =========================
def query_kb(question):
    try:
        response = client.retrieve_and_generate(
            input={
                "text": question
            },
            retrieveAndGenerateConfiguration={
                "type": "KNOWLEDGE_BASE",
                "knowledgeBaseConfiguration": {
                    "knowledgeBaseId": "W05C7DXU51",
                    "modelArn": f"arn:aws:bedrock:{us-east-1}::foundation-model/{anthropic.claude-3-sonnet-20240229-v1:0}",
                }
            }
        )

        # Extract answer
        answer = response.get("output", {}).get("text", "No answer found.")
        return answer

    except Exception as e:
        return f"❌ Error: {str(e)}"


