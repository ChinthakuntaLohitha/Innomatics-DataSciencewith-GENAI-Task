import streamlit as st
from rag_app import query_kb

st.set_page_config(page_title="Enterprise KB Chatbot")

st.title("📚 Enterprise Knowledge Base Q&A")

user_query = st.text_input("Ask your question:")

if st.button("Ask"):
    if user_query:
        with st.spinner("Thinking..."):
            answer = query_kb(user_query)
        st.success(answer)