from flask import Flask, request
from datetime import datetime

app = Flask(__name__)

# Home Route
@app.route("/")
def home():
    return """
    <h2>Welcome to the Flask Name App 🚀</h2>
    <p>Try these URLs:</p>
    <ul>
        <li>/upper?name=lohitha</li>
        <li>/reverse?name=lohitha</li>
        <li>/count?name=lohitha</li>
        <li>/greet?name=lohitha</li>
        <li>/fun?name=lohitha</li>
    </ul>
    """

# 1️⃣ Convert name to UPPERCASE
@app.route("/upper")
def upper_name():
    name = request.args.get("name", "Guest")
    return f"<h1>{name.upper()}</h1>"

# 2️⃣ Reverse the name
@app.route("/reverse")
def reverse_name():
    name = request.args.get("name", "Guest")
    return f"<h1>Reversed Name: {name[::-1]}</h1>"

# 3️⃣ Count characters
@app.route("/count")
def count_name():
    name = request.args.get("name", "")
    return f"<h1>Character Count: {len(name)}</h1>"

# 4️⃣ Greet based on time
@app.route("/greet")
def greet_user():
    name = request.args.get("name", "Guest")
    hour = datetime.now().hour

    if hour < 12:
        greet = "Good Morning ☀️"
    elif hour < 18:
        greet = "Good Afternoon 🌤️"
    else:
        greet = "Good Evening 🌙"

    return f"<h1>{greet}, {name.upper()}!</h1>"

# 5️⃣ Fun Emoji Mode 😄
@app.route("/fun")
def fun_mode():
    name = request.args.get("name", "Guest")
    return f"<h1>😎🔥 {name.upper()} 🔥😎</h1>"

if __name__ == "__main__":
    app.run(debug=True)