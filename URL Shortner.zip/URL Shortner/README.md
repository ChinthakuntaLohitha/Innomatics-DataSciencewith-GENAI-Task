# URL Shortener

A simple URL shortener built with Flask, SQLAlchemy, and validators.

## Features

- Shorten long URLs to compact codes
- Redirect to original URLs using short codes
- View history of all shortened URLs
- URL validation
- Bootstrap UI

## Installation

1. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

## Usage

1. Run the application:
   ```
   python app.py
   ```

2. Open your browser and go to `http://127.0.0.1:5000/`

3. Enter a URL to shorten and click "Shorten URL"

4. Use the generated short URL to redirect to the original

5. View all shortened URLs at `/history`

## Troubleshooting

- Ensure all packages are installed
- Database `url.db` is created automatically on first run